export { default as userController } from "./userController";
